import cv2
from screeninfo import get_monitors

def obter_credenciais(arquivo_txt):
    user = None
    password = None
    ipCam = None
    port = None
    monitor_idx = 0

    with open(arquivo_txt, 'r') as arquivo:
        for linha in arquivo:
            linha = linha.strip()

            if linha.startswith('user='):
                user = linha.split('=')[1]

            elif linha.startswith('password='):
                password = linha.split('=')[1]

            elif linha.startswith('ipCam='):
                ipCam = linha.split('=')[1]

            elif linha.startswith('port='):
                port = linha.split('=')[1]

            elif linha.startswith('monitor_idx='):
                try:
                    monitor_idx = int(linha.split('=')[1])
                except ValueError:
                    print("Erro ao converter monitor_idx para número, usando o valor padrão 0.")
                    monitor_idx = 0

    return user, password, ipCam, port, monitor_idx

def openSpecificMonitor(monitor_idx):
    monitores = get_monitors()

    if monitor_idx >= len(monitores):
        print(f"Monitor {monitor_idx} não encontrado. Exibindo no monitor principal.")
        monitor_idx = 0

    monitor = monitores[monitor_idx]

    cv2.namedWindow('IP Camera Stream', cv2.WINDOW_NORMAL)
    cv2.moveWindow('IP Camera Stream', monitor.x, monitor.y)
    
    cv2.setWindowProperty('IP Camera Stream', cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

arquivo_txt = '/root/pythonCamIP/config.txt'

user, password, ipCam, port, monitor_idx = obter_credenciais(arquivo_txt)

if user and password:
    url_rtsp = f"rtsp://{user}:{password}@{ipCam}:{port}/cam/realmonitor?channel=1&subtype=0"

    cap = cv2.VideoCapture(url_rtsp)

    if not cap.isOpened():
        print("Não foi possível conectar à câmera")
        exit()

    # monitor_idx = 0 
    window_width = 1024  
    window_height = 768 

    openSpecificMonitor(monitor_idx)

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Falha ao capturar a imagem da câmera.")
            break

        # Exibe o 
        cv2.imshow('IP Camera Stream', frame)

        if cv2.waitKey(1) & 0xFF == ord('x'):
            break

    cap.release()
    cv2.destroyAllWindows()
else:
    print("Credenciais não encontradas no arquivo.")
