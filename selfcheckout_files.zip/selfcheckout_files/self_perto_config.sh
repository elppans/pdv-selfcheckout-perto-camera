# Kill camera
pkill -f main.py
# Adjust resolution and touchscreen - FHD
#xrandr --output HDMI-1 --mode 1920x1080 --primary
#xrandr --output DP-2 --mode 1024x768 --right-of HDMI-1 --pos 1920x156
#xinput set-prop "ILITEK ILITEK-TP" "Coordinate Transformation Matrix" 0.652 0 0  0 1 0  0 0 1
# Adjust resolution and touchscreen - 1024x768
xrandr --output HDMI-1 --mode 1024x768 --primary
xrandr --output DP-2 --mode 1024x768 --right-of HDMI-1 --pos 1024x0
xinput set-prop "ILITEK ILITEK-TP" "Coordinate Transformation Matrix" 0.5 0 0  0 1 0  0 0 1
# Open camera
sleep 10
python3 /root/pythonCamIP/main.py

